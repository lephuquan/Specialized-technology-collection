package com.practice.learningJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningJpaApplication.class, args);
	}

}

package com.practice.learningJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

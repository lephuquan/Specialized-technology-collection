package com.personalize.demo_protect_file;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProtectFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProtectFileApplication.class, args);
	}

}

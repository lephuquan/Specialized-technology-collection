package com.dev.lpq.demo_security_jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}

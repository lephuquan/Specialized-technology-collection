package com.lpq.savefilefolder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveFileFolderApplicationTests {

	@Test
	void contextLoads() {
	}

}

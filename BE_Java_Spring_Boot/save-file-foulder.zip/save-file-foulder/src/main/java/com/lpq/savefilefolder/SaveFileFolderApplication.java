package com.lpq.savefilefolder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveFileFolderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaveFileFolderApplication.class, args);
	}

}
